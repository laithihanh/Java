/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BTTH_01;

/**
 *
 * @author ADMIN
 */
public interface IAccuracy {
    public static final int TWO_NUMBER = 2;
    public static final int THREE_NUMBER = 3;
    public static final int FOUR_NUMBER = 4;
    public void setAccuracy(int accuracy);
}
