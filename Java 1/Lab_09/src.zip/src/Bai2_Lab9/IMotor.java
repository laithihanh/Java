/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2_Lab9;

/**
 *
 * @author USER
 */
public interface IMotor {
    public void inputInfor(); //nhập thông tin motor
    public void displayInfor(); //hiển thị thông tin motor
    public void changeInfor(); //thay đổi thông tin motor
    
    
}
