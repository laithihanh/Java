/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai3_Lab9;

/**
 *
 * @author USER
 */
public interface ICountry {
    public void input();
    public void display();
    public float everageArea(double area, long numberPerson);//Tính diện tích
}
