/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lap5;

/**
 *
 * @author ADMIN
 */
public class Product_bai1 {
    public static void main(String[] args) {
        Bai1 b1=new Bai1();
        b1.input(); 
        b1.display();
        b1.caculateSalePrice();
    }
}
